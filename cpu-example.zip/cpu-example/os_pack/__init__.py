import os

code_dir = os.path.dirname(__file__)
