from joblib import load
import numpy as np
import json


model = load("heartfailure.pkl")

def my_prediction(id):
    dummy = np.array(id)
    dummyT = dummy.reshape(1,-1)
    prediction = my_model.predict(dummyT)
    return str(prediction[0])

